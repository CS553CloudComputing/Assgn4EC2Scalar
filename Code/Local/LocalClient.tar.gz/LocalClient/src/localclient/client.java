package localclient;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import org.apache.commons.io.IOUtils;

public class client {
	
	public static void main(String[] args) throws IOException
	{
		String servIP;
		int portNumber;
		String fileName;
		Socket connSocket;
		byte[] bytesSend,bytesRec = null;
		InputStream inputStrm;
		FileOutputStream fileOutStrm;
		BufferedInputStream bufferInStrm;
		OutputStream outStream;
		InputStream inStream;
		//int bytesRead;
		String RecString;
		String recFileloc = "//home//ubuntu//input//workload_out.txt";
		File inputFile;
		
		if(args[0].isEmpty())
		{
			servIP = "127.0.0.1";			
		}
		else
		{
			servIP = args[0];			
		}
		 
		if(args[1].isEmpty())
		{
			portNumber = 50000;			
		}
		else
		{
			portNumber = Integer.parseInt(args[1]);			
		}
		
		if(args[2].isEmpty())
		{
			fileName = "//home//ubuntu//input//workload.txt";
		}
		else
		{
			fileName = args[2];
		}
		
		connSocket = new Socket(servIP, portNumber);
		inputFile = new File(fileName);
		bytesSend = new byte[(int) inputFile.length()];
		bytesRec = new byte[1024]; 
		bufferInStrm = new BufferedInputStream(new FileInputStream(inputFile));
		bufferInStrm.read(bytesSend,0,bytesSend.length);
		outStream = connSocket.getOutputStream();
		outStream.write(bytesSend, 0, bytesSend.length);
		outStream.flush();
		bufferInStrm.close();

		//file sent to the scheduler
		//receive acknowledgement from the scheduler
		/*
		
		inStream = connSocket.getInputStream();		
		int bytesRead = inStream.read(bytesRec, 0, bytesRec.length);
    	int curLoc = bytesRead;
    	while(bytesRead>-1)
    	{
    		bytesRead = inStream.read(bytesRec, curLoc, bytesRec.length-curLoc);
    		if(bytesRead>=0)
    		{
    			curLoc+=bytesRead;	    			
    		}
    	}
    	
    	BufferedOutputStream bufferOutStrm = new BufferedOutputStream(new FileOutputStream(recFileloc));
		bufferOutStrm.write(bytesRec, 0, curLoc);
    	//Write the received data to a file on local disk
    	bufferOutStrm.close();*/
    	//After receiving the file close the socket		
		connSocket.close();
		
		
	}

}
