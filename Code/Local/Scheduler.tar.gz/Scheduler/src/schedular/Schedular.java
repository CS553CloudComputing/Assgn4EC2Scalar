package schedular;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;


public class Schedular {
	static ServerSocket servsocket;
	static List<Future> futures = new ArrayList<>();

	public static void main(String[] args) throws IOException, InterruptedException {
		try 
		{
		
			int portNumber;
			int numOfThreads;
			String recFileloc = "//home//kanwal//ubuntu//output//workload.txt";
			String outFileloc = "//home//kanwal//ubuntu//output//workload_out.txt";
			File recFile = new File(recFileloc);
			Socket socket;
			byte[] bytesRec = new byte[1024];
			BufferedOutputStream bufferOutStrm;
			InputStream inStream;
			int bytesRead = 0;
			int curLoc = 0;
			int iteration = 1;
			
		    Queue<Element> queue = new ConcurrentLinkedQueue<Element>();
			Queue<ResponseElement>resQueue = new ConcurrentLinkedQueue<ResponseElement>();
			ReadFile rFile;
			ResponseElement resEle;
			
			if(args[0].isEmpty())
			{
				portNumber = 50000;			
			}
			else
			{
				portNumber = Integer.parseInt(args[0]);	
				System.out.println("Port received : "+portNumber);
			}
			servsocket = new ServerSocket(portNumber);
			
			
			if(args[1].isEmpty())
			{
				numOfThreads = 1;			
			}
			else
			{
				numOfThreads = Integer.parseInt(args[1]);	
				System.out.println("Num of threads : "+numOfThreads);
			}
			
			System.out.println("Starting server");
		    while (true) {
		    	System.out.println("Socket open");
		    	socket = servsocket.accept();
		    	inStream = socket.getInputStream();
		    	bytesRead = inStream.read(bytesRec, 0, bytesRec.length);
		    	curLoc = bytesRead;
		    	while(bytesRead>-1)
		    	{
		    		bytesRead = inStream.read(bytesRec, curLoc, bytesRec.length-curLoc);
		    		if(bytesRead>=0)
		    		{
		    			curLoc+=bytesRead;	    			
		    		}
		    	}
		    	bufferOutStrm = new BufferedOutputStream(new FileOutputStream(recFile));
		    	bufferOutStrm.write(bytesRec, 0, curLoc);
		    	//Write the received data to a file on local disk
		    	bufferOutStrm.close();
		    	//After receiving the file close the socket
		    	socket.close();
		    	System.out.println("Socket closed");
		    	//Open the file to add task to Queue using the producer
		    	rFile = new ReadFile(recFileloc,queue);
		    	Thread producer = new Thread(rFile);
		    	producer.setName("Producer #"+iteration);
		    	producer.start();
		    	//Start workers to start consuming the tasks
		    	ExecutorService service = Executors.newFixedThreadPool(numOfThreads);
    	        for (int j =0; j<numOfThreads; j++)
    	        {
    	        	System.out.println("Starting thread num "+(j+1));
    	    	    Callable worker = new Consumer(queue,resQueue,iteration+"_"+j);
    	    	    futures.add( service.submit(worker));
    	        }
	    	    iteration++;
	    	    System.out.println("Iteration : "+iteration);
	    	    service.shutdown();
	    	    //service.awaitTermination(30, TimeUnit.SECONDS);
	    	    
	    	    for (Future f : futures) {
	    	        try {
	    	        	System.out.println("Executing future");
						f.get();
						//f.get(1, TimeUnit.MINUTES);
					} catch (ExecutionException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	    	    }
	    	    //Thread.currentThread().join();
	    	    futures.clear();
	    	    BufferedWriter bufwriter = new BufferedWriter(new FileWriter(outFileloc,true));
	    	    while(!resQueue.isEmpty())
	    	    {
	    	    	
	    	    	resEle =resQueue.poll();
	    	    	if(resEle != null)
	    	    	{
	    	    		//System.out.println(resEle.getLine() + " Status : " +resEle.isStatus());
	    	    		bufwriter.write(resEle.getLine() +" " + resEle.getIndex()  + " Status : " +resEle.isStatus());
	    	    		bufwriter.newLine();
	    	    	}
	    	    	
	    	    	
	    	    }
	    	    System.out.println("Iteration complete");
	    	    bufwriter.close();
	    	    //send file back to client
	    	    /*
	    	    OutputStream outStream = socket.getOutputStream();
	    	    BufferedInputStream bufferInStrm = new BufferedInputStream(new FileInputStream(outFileloc));
	    	    File inputFile = new File(outFileloc);
	    	    byte[] bytesSend = new byte[(int) inputFile.length()];
				bufferInStrm.read(bytesSend,0,bytesSend.length);
				outStream.write(bytesSend, 0, bytesSend.length);
				outStream.flush();
				bufferInStrm.close();*/
		    }

		}
		finally
		{
			servsocket.close();			
		}

	}

}
