package schedular;

import java.util.Queue;

public class Producer{

	private final Queue<Element> queue;
	
	public Producer(Queue<Element> _queue)
	{
		this.queue = _queue;
	}
	
	public void produce(Element _line)
	{
		queue.offer(_line);
		synchronized(queue)
		{
			queue.notifyAll();
		}	

	}	
}
