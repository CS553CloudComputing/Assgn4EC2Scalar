package schedular;

import java.util.Queue;
import java.util.concurrent.Callable;

public class Consumer implements Callable<Object> {
	private final Queue<Element> queue;
	private final Queue<ResponseElement> respQueue;
	String[] words;
	ResponseElement respEle;
	String threadName;
	public Thread t;
	
	public Consumer(Queue<Element> _queue,Queue<ResponseElement> _respQueue,String _threadNum)
	{
		respQueue = _respQueue;
		this.queue = _queue;
		threadName = "Worker #"+_threadNum;
	}
	
	public void consume()
	{
		while(!queue.isEmpty())	
		{
			Element line = queue.poll();
			
			if(line != null)
			{
				words =  line.getLine().split(" ");
			
				respEle = new ResponseElement();
				respEle.setIndex(line.getIndex());
				respEle.setLine(line.getLine());
				try {
					Thread.currentThread().setName(threadName);
					System.out.println(threadName+ " started... - "+words[1]);
					Thread.sleep(Long.parseLong( words[1]));
					System.out.println(threadName+ " ended... - "+ words[1]);
				} catch (ArrayIndexOutOfBoundsException e)
				{
					System.out.println("error thrown");
					e.printStackTrace();
				} catch (NumberFormatException e) {
					//in case of exception mark status as false
					respEle.setStatus(false);
					e.printStackTrace();
				} catch (InterruptedException e) {
					//in case of exception mark status as false
					respEle.setStatus(false);
					e.printStackTrace();
				}
				
				respEle.setStatus(true);				
				respQueue.offer(respEle);
			}
		}

	}

	/*
	@Override
	public void run() {
		consume();
		
	}*/

	@Override
	public Object call() throws Exception {
		// TODO Auto-generated method stub
		consume();
		return null;
	}

}
