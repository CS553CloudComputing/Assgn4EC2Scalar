package schedular;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Queue;
import java.util.Scanner;

public class ReadFile implements Runnable {
	FileInputStream iStrm;
	Scanner scObj;
	String fPath;
	String line;
	Producer pro;
	int index;
	public Thread t;
	
	public ReadFile(String _filePath,Queue<Element> _queue){
		
		iStrm = null;
		fPath = _filePath;
		pro = new Producer(_queue); 
		index = 0;
		
	}

	@Override
	public void run() {
		try
		{
			iStrm = new FileInputStream(fPath);	
			scObj = new Scanner(iStrm);
			while(scObj.hasNextLine())
			{
				line = scObj.nextLine();
				Element el = new Element();
				el.setIndex(index++);
				el.setLine(line);
				pro.produce(el);
				 //return line;
				//index++;
			}
			if(scObj.ioException() != null)
			{
				throw scObj.ioException();
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally
		{
			if(iStrm != null)
			{
				try {
					iStrm.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				
			}
			if(scObj != null)
			{
				scObj.close();
			}
		}
		
	}

}